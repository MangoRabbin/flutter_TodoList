import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'dart:async';
import 'package:path/path.dart';

import 'package:finalexam/model/item_model.dart';


class AdditionScreen extends StatefulWidget {
  @override
  _AdditionScreenState createState() => _AdditionScreenState();
}

class _AdditionScreenState extends State<AdditionScreen> {
  
  Product product;
  File _image;
  TextEditingController nameController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  FocusNode nameFocus = FocusNode();
  FocusNode priceFocus = FocusNode();
  FocusNode descriptionFocus = FocusNode();
  String category ;
  DateTime created;
  DateTime modify;
  String uid;
  String name;
  bool picUpload;
  bool dataUploading;
  
  @override
  void initState() {
    super.initState();
    created = DateTime.now();
    modify = DateTime.now();
    picUpload = false;
    dataUploading = false;
    category = "accessories" ;
  }

  @override
  void dispose() {
    nameController.dispose();
    priceController.dispose();
    descriptionController.dispose();
    nameFocus.dispose();
    priceFocus.dispose();
    descriptionFocus.dispose();
    super.dispose();
  }
  
  Future getImage() async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = image;
      picUpload = true;
    });
  }

  Future _saved(BuildContext context) async {
    String imageUrl = "https://firebasestorage.googleapis.com/v0/b/mobilefinalexam-66c65.appspot.com/o/default-image2.jpg?alt=media&token=85ba6ed0-82d9-40a2-a667-1a3a07d08058";

    if (picUpload) {
      try {
        // 같은 이름의 사진이 이미 존재 한다. => 이름 넣어주기
        var exRef = FirebaseStorage.instance.ref().child(
            basename(_image.path).toString());
        var downLoadUrl = await exRef.getDownloadURL();
        imageUrl = downLoadUrl.toString();
      }
      catch (e) {
        // 같은 이름의 사진이 없다. => URL 넣어주기.
        debugPrint(e.toString());
        StorageReference firebaseStorageRef = FirebaseStorage.instance.ref()
            .child(basename(_image.path).toString());
        StorageUploadTask task = firebaseStorageRef.putFile(_image);
        // imageUrl = await (await firebaseStorageRefgetDownloadURL()).toString();
        var dowurl = await (await task.onComplete).ref.getDownloadURL();
        imageUrl = dowurl.toString();
      }
    }
    setState(() {
      dataUploading = true;
    });
    await Firestore.instance.collection('Product').document().setData({
      "Name": nameController.text,
      "Price": int.parse(priceController.text),
      "Image": imageUrl,
      "Category": category,
      "UID": uid,
      "Likes": [],
      "Modify": modify.toString(),
      "Created": created.toString(),
      "Info": descriptionController.text.toString(),
    });
    Navigator.of(context).pop();
  }
  @override
  Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.grey,
          title: Text(
              'Add',
              style: TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold
              )
          ),
          titleSpacing: 0.0,
          centerTitle: true,
          leading: Center(
            child: GestureDetector(
              child: Text(
                "Cancel",
                style: TextStyle(
                    color: Colors.black
                ),
              ),
              onTap: () => Navigator.of(context).pop(),
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text(
                "Save",
                style: TextStyle(
                    color: Colors.white
                ),
              ),
              // onPressed: () => print("Save"),
              onPressed: () => _saved(context),
              //TODO: send data to firebase.
            )
          ],
        ),
        body: FutureBuilder(
          future: FirebaseAuth.instance.currentUser(),
          builder: (context, AsyncSnapshot<FirebaseUser> snapshot) {
            if (snapshot.hasData && !dataUploading) {
              uid = snapshot.data.uid;
              return SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.only(top: 10.0, left: 30.0, right: 30.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Container(
                        width: MediaQuery
                            .of(context)
                            .size
                            .width * 0.8,
                        height: MediaQuery
                            .of(context)
                            .size
                            .height * 0.3,
                        child: Center(
                            child: _image == null
                                ? Image.network(
                                "https://firebasestorage.googleapis.com/v0/b/mobilefinalexam-66c65.appspot.com/o/default-image2.jpg?alt=media&token=85ba6ed0-82d9-40a2-a667-1a3a07d08058")
                                : Image.file(_image)
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(left: MediaQuery
                            .of(context)
                            .size
                            .width * 0.7),
                        child: IconButton(
                          icon: Icon(Icons.camera_alt),
                          onPressed: () => getImage(),
                        ),
                      ),
                      SizedBox(
                          height: MediaQuery
                              .of(context)
                              .size
                              .height * 0.05
                      ),
                      Container(
                        width: MediaQuery
                            .of(context)
                            .size
                            .width * 0.8,
                        padding: EdgeInsets.only(bottom: 20.0),
                        child: TextFormField(
                          focusNode: nameFocus,
                          controller: nameController,
                          onFieldSubmitted: (v) {
                            setState(() {
                              name = v;
                            });
                            FocusScope.of(context).requestFocus(priceFocus);
                          },
                          style: TextStyle(
                              color: Colors.blueAccent,
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold
                          ),
                          decoration: InputDecoration(
                            hintText: "Product Name",
                            hintStyle: TextStyle(
                                color: Colors.blueAccent,
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery
                            .of(context)
                            .size
                            .width * 0.8,
                        padding: EdgeInsets.only(bottom: 20.0),
                        child: TextFormField(
                          focusNode: priceFocus,
                          onFieldSubmitted: (v) =>
                              FocusScope.of(context).requestFocus(descriptionFocus),
                          controller: priceController,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            color: Colors.blueAccent,
                            fontSize: 18.0,
                          ),
                          decoration: InputDecoration(
                              hintText: "Price",
                              hintStyle: TextStyle(
                                color: Colors.blueAccent,
                                fontSize: 18.0,
                              )
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery
                            .of(context)
                            .size
                            .width * 0.8,
                        child: TextField(
                          focusNode: descriptionFocus,
                          controller: descriptionController,
                          style: TextStyle(
                            color: Colors.blueAccent,
                            fontSize: 18.0,
                          ),
                          decoration: InputDecoration(
                              hintText: "Desicription",
                              hintStyle: TextStyle(
                                color: Colors.blueAccent,
                                fontSize: 18.0,
                              )
                          ),
                        ),
                      ),

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          DropdownButton<String>(
                            value: category,
                            onChanged: (String newValue) =>
                                setState(() {
                                  category = newValue;
                                }),
                            items: <String>['accessories', 'home', 'clothing'].map<
                                DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value)
                              );
                            }).toList(),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(.0, 8.0, 16.0, .0),
                            child: Text(
                              'creator : <${snapshot.data.uid}>\n${created
                                  .toString()}:Created\n${modify
                                  .toString()}:Modified',
                              style: TextStyle(
                                  fontSize: 14.0,
                                  color: Colors.grey
                              ),
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }
            return
              Center(child: CircularProgressIndicator());
          },
        )
      );
    }

}

