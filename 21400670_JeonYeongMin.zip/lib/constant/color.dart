import 'package:flutter/material.dart';

class MyColors {
  final Color myBlue = Colors.blueAccent;
  final Color myRed = Colors.redAccent;
  final Color myGreen = Colors.greenAccent;
}