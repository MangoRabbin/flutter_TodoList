import 'package:flutter/material.dart';

class ScreenUtil {
  static double width;
  static double height;
}

const TextStyle myTextStyle = 
  TextStyle(
    color: Colors.white,
    fontWeight: FontWeight.bold,
    fontSize: 14.0
  );