import 'package:flutter/material.dart';
import 'package:finalexam/app.dart';
void main() => runApp(FinalExam());

