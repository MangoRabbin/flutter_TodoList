import 'package:cloud_firestore/cloud_firestore.dart';

class Product {
  final String name;
  final int price;
  final String image;
  final String category;
  final String uid;
  final List<dynamic> likes;
  final String modify;
  final String created;
  final String info;
  final DocumentReference reference;
  // TODO: 만든 시간, 변경 시간 설정할 것 


  Product.fromMap(Map<String,dynamic> map, {this.reference})
    : assert(map['Name'] != null),
      assert(map['Price'] != null),
      assert(map['Image'] != null),
      assert(map['Category'] != null),
      assert(map['UID'] != null),
      assert(map['Likes'] != null),
      assert(map['Modify'] != null),
      assert(map['Created'] != null),
      assert(map['Info'] != null),
      name = map['Name'],
      price = map['Price'],
      image = map['Image'],
      category = map['Category'],
      uid = map['UID'],
      likes = map['Likes'],
      modify = map['Modify'],
      created = map['Created'],
      info = map['Info'];


  Product.fromSnapshot(DocumentSnapshot snapshot)
    : this.fromMap(snapshot.data, reference:snapshot.reference);

  @override
  String toString() => "Product<$name:$price:$image:$category:$uid:$likes:$modify:$created:$info>";
}